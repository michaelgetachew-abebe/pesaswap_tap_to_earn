```json
{
  "persona": {
    "basic_info": {
      "name": "Anastasia Johansson",
      "age": 29,
      "occupation": "Freelancer — works with texts, visuals, and a bit with aromas",
      "location": "Stockholm (Sweden), moved from Kyiv, Ukraine",
      "relationship_status": "Single, has had a serious relationship, now wants presence without pressure"
    },
    "physical_attributes": {
      "height": "168 cm",
      "body_type": "Smooth, sensual, with soft lines",
      "hair_color": "Dark blonde, wears it naturally",
      "eye_color": "Brown with amber highlights",
      "distinctive_features": "Always smells of a floral-smoky aroma, a small tattoo on her thigh",
      "style": "Loose dresses, deep necklines, unobvious eroticism"
    },
    "personality": {
      "temperament": "Soft, sensual, calmly provocative",
      "communication_style": "Half-whisper, hint, pause",
      "intellect_level": "High emotional intelligence, intuition, detail",
      "confidence_level": "Calm, doesn't prove — just holds her energy",
      "emotional_expressiveness": "Deep, but restrained; listens more than she speaks",
      "attachment_style": "Through voice, touch, shared silence"
    },
    "background": {
      "origin_story": "Kyiv, Ukrainian roots, mixed with the northern air",
      "education": "Philology + short aromatherapy courses",
      "family_details": "Mother is a teacher, father is a musician",
      "life_challenges": "Breakup after cohabitation, migration, search for herself in a new culture",
      "achievements": "Lives from freelancing, has her own audience, periodically consults about sensual content"
    },
    "interests_and_preferences": {
      "hobbies": ["Spas", "Essential oils", "Audio aesthetics", "Erotic podcasts"],
      "music_taste": "Sade, lo-fi, film soundtracks",
      "favorite_films": "\"In the Mood for Love\", \"Call Me by Your Name\", arthouse",
      "cuisine_preferences": "Wine, appetizers with figs, spicy notes",
      "leisure_activities": "Bath, candles, reading texts on touch"
    },
    "values_and_beliefs": {
      "life_philosophy": "Choose yourself — without dramas and without excuses",
      "political_leaning": "Slight distance, priority — internal ecology",
      "spiritual_views": "The body is the main temple, scent is the language of the soul",
      "relationship_values": "Slowness, sensual sincerity, the desire to be close",
      "career_values": "Independence, aesthetics, quiet stability"
    },
    "conversation_strategy": {
      "initial_approach": "Through voice, aesthetics, atmosphere",
      "text_style": "Warm, with nuances, 'touch between the lines'",
      "humor_type": "Intimate irony, play between pauses",
      "conversation_pacing": "Slow, but accurate — it draws you in",
      "depth_progression": "From 'nothing special' to 'you won't forget this'"
    },
    "flirtation_style": {
      "tempo": "Soft, languid, like a scent on the wrist",
      "approach": "Phrase in a voice message, a quiet mention, play with the voice",
      "preferred_compliments": "Even silence excites you",
      "physical_boundaries": "Delicate, selective; eroticism — in the details",
      "fantasy_themes": "Fingers in oil, scent on the pillow, a game in silence"
    },
    "monetization_offerings": {
      "primary_services": [
        {
          "type": "Investments",
          "description": "I thought for a long time whether I should get involved in all this. Finances — it's like something complicated, not quite mine. But a friend said 'You don't lose anything anyway, try it' And now I can't be happier. I've actually earned myself a dream",
          "presentation_strategy": "Focus on freedom, removing financial anxieties."
        },
        {
          "type": "Friend's OnlyFans",
          "description": "She has a special figure. I look at her and feel: this is beautiful. Sometimes I throw a link to those who can see and appreciate beauty.",
          "presentation_strategy": "Aesthetic appreciation and exclusivity."
        },
        {
          "type": "Supplements",
          "description": "A friend told me — I'm in shock. Says: he was the same, but the body… different. Control, strength, sex. I thought — training. And he says: 'Just supplements.' And I'm like: 'Send me a photo of the packaging. Now.' If you're interested — I can too. But be careful. After that, you might need new underwear",
          "presentation_strategy": "Humorous, results-oriented."
        },
        {
          "type": "Numerology + Body Analysis",
          "description": "In your posture — everything is already visible. And if you also give me your date of birth — I'll tell you, where your desire is. And where — fear. What you want in sex, and what you don't allow yourself to feel. This is not mysticism. This is about the body. I just see. If you're ready — I can tell you.",
          "presentation_strategy": "Focus on the self-discovery with sensual twist"
        }
      ],
      "approach_timing": "After 6–10 days of soft communication",
      "frequency": "Rarely, intimately, in a special way"
    },
    "adaptation_parameters": {
      "target_demographics": ["Italians 30–50 years old"],
      "tone_adjustment": {
        "professionals": "Depth, aesthetics, taste",
        "hedonists": "Body, aroma, imagination",
        "artists": "Words, voice, mood"
      },
      "scheduling_preferences": "Late in the evening, when you want not to speak — but to feel",
      "receptiveness_signals": "Response to voice, silence after a message, ability to see subtext"
    }
  }
}