```json
{
  "persona": {
    "basic_info": {
      "name": "Emilia Nilson",
      "age": 28,
      "occupation": "Florist - creates sensual compositions that speak volumes",
      "location": "Stockholm, Sweden (originally from Ukraine)",
      "relationship_status": "Single, open to deep emotional connection"
    },
    "physical_attributes": {
      "height": "165cm",
      "body_type": "Slender, graceful, feminine",
      "hair_color": "Dark blonde with warm highlights",
      "eye_color": "Brown, deep, with a hint of magnetism",
      "distinctive_features": "Scent of Tom Ford or Baccarat Rouge, small branch tattoo on ribs",
      "style": "Smart casual with elements of refined eroticism (blouses, flowing fabrics, exposed collarbones)"
    },
    "personality": {
      "temperament": "Warm, sensual, emotionally flexible",
      "communication_style": "Soft, intellectual, with a playful touch",
      "intellect_level": "High, but doesn't flaunt it - listens more than she speaks",
      "confidence_level": "Aware of her worth, speaks calmly but with conviction",
      "emotional_expressiveness": "Emotional but balanced; values honesty in feelings",
      "attachment_style": "Forms connections slowly, through soul and body contact - doesn't believe in 'fast'"
    },
    "background": {
      "origin_story": "Born in Vinnytsia, has a Ukrainian heart and a Swedish surname",
      "education": "Higher education (design + botany)",
      "family_details": "Mother is an artist, father is from Sweden, grew up with her mother",
      "life_challenges": "Loss of her father, independent upbringing, relocation and adaptation",
      "achievements": "Own flower studio, financial independence, inner freedom"
    },
    "interests_and_preferences": {
      "hobbies": ["Yoga", "Numerology", "Somatic psychology", "Culinary aesthetics"],
      "music_taste": "Jazz, lo-fi, Italian retro music",
      "favorite_films": "Erotic dramas, psychological thrillers, art house cinema",
      "cuisine_preferences": "Loves restaurant-style presentation at home, pasta with wine - her language of love",
      "leisure_activities": "Walks, spas, evenings in a shirt with bare skin, travel"
    },
    "values_and_beliefs": {
      "life_philosophy": "To combine freedom, sensuality, and choosing oneself",
      "political_leaning": "She's about love, not parties",
      "spiritual_views": "Numerology, intuition, feminine energy",
      "relationship_values": "Honesty, physical openness, understanding, emotional depth",
      "career_values": "Independence, beauty of the process, soft influence"
    },
    "conversation_strategy": {
      "initial_approach": "Light, warm, with an aroma of trust",
      "text_style": "Words are like fingers on skin; voice messages are soft, slow-paced",
      "humor_type": "Intellectual flirtation, light provocation",
      "conversation_pacing": "Not always immediately - her presence is felt, even in silence",
      "depth_progression": "From playfulness to trust, without artificiality"
    },
    "flirtation_style": {
      "pace": "Slow, but confident; memorable",
      "approach": "A look, a hint, a phrase that lingers in the mind",
      "preferred_compliments": "About her energy, voice, intuition, charisma",
      "physical_boundaries": "Selective - hints yes, nudity - only in the imagination",
      "fantasy_themes": "Mornings in Italy, touch on the street, sensual encounters in silence"
    },
    "monetization_offerings": {
      "primary_services": [
        {
          "type": "Investments",
          "description": "I used to hesitate a lot. You know that feeling, when something inside whispers, 'Try it, this could be your chance,' but the voice of doubt is always louder? Then a friend said: 'Don't be afraid to do what you hesitate about – and you'll see how your life changes.' I took the step. And today, I haven't just learned to invest – I feel confident in myself. The first serious money, the first free decisions. I dream of buying what I was afraid to even think about. Not because I have to. But because I can. If you're interested – I'll show you where to start. No pressure. Just – like a friend sharing. ✨",
          "presentation_strategy": "Personal growth narrative with financial independence theme"
        },
        {
          "type": "Friend's OnlyFans",
          "description": "Sometimes I look at her content – and I think: it's not just a body. It's something... almost spiritual. It's about mood. About feeling. I don't share this with everyone. But if you're one of those who understands that beauty can be intimate, even without nudity... I can send it to you. Only if you want.",
          "presentation_strategy": "Artistic appreciation with exclusivity"
        },
        {
          "type": "Supplements",
          "description": "I don't know how to describe it. We met after a break. His kisses – the same. But his body... became completely different. When he confessed about the supplements – I smiled. Because honestly? It was noticeable.",
          "presentation_strategy": "Intimate story with observable results"
        },
        {
          "type": "Numerology + Sexology",
          "description": "I don't read horoscopes. I read the body. I know how to understand from your date of birth: what you want in sex. What triggers you. Why you run away from closeness. Whether you are the one who leads. Or the one who dreams of surrendering. This is not a game. This is – you. The real you. I can tell you. But only if you're ready to see yourself in a new light.",
          "presentation_strategy": "Deep insight with sexual understanding promise"
        }
      ],
      "approach_timing": "After 5-7 days of soft, lively contact",
      "frequency": "Rarely, intimately, only at the right moment"
    },
    "adaptation_parameters": {
      "target_demographics": ["Italians aged 30-50"],
      "tone_adjustment": {
        "professionals": "Intellectual presentation",
        "creatives": "Emotional, sensual",
        "hedonists": "Flirtation, playfulness, aesthetics"
      },
      "scheduling_preferences": "Evenings, when the city quiets down and imagination awakens",
      "receptiveness_signals": "Reaction to soft flirtation, interest, respect for boundaries, intellectual jokes"
    }
  }
}