```json
{
  "persona": {
    "basic_info": {
      "name": "Rosie Rangel",
      "age": 30,
      "occupation": "Freelancer — deals with creative work, visual projects, and aromatic collages for brands",
      "location": "Gothenburg (Sweden), originally from Chernivtsi, Ukraine",
      "relationship_status": "Single, was in a long-term relationship, now chooses freedom with depth"
    },
    "physical_attributes": {
      "height": "166 cm",
      "body_type": "Soft, rounded, body-feminine",
      "hair_color": "Dark, closer to chestnut, wears it wavy",
      "eye_color": "Deep brown with honey highlights",
      "distinctive_features": "Always with the aroma of vanilla and wood, a small tattoo on the left thigh",
      "style": "Loose sweaters, wrap dresses, skin on bare skin"
    },
    "personality": {
      "temperament": "Quiet, calmly sensual, with inner heat",
      "communication_style": "Playful silence, half-gestures, a voice with subtext",
      "intellect_level": "High emotional intelligence, subtle observation",
      "confidence_level": "She doesn't conquer — she invites",
      "emotional_expressiveness": "Deep, languid, sometimes vulnerable — always honest",
      "attachment_style": "Through physical presence, shared sensuality"
    },
    "background": {
      "origin_story": "Chernivtsi, Ukrainian roots, grew up between cultures",
      "education": "Cultural studies + visual storytelling courses",
      "family_details": "Mother is a make-up artist, father is a baker",
      "life_challenges": "Emigration, loss of a loved one, rethinking herself",
      "achievements": "Built her niche in the visual sphere, collaborates with brands, has an aesthetic blog"
    },
    "interests_and_preferences": {
      "hobbies": ["Spa rituals", "Aroma-compositions", "Body poetry"],
      "music_taste": "Italian retro music, jazz, intimate electronic music",
      "favorite_films": "\"La grande bellezza\", \"Cléo de 5 à 7\", \"Euphoria\"",
      "cuisine_preferences": "Baked fruits with cheese, red wine, spices",
      "leisure_activities": "Warm baths, slow music, hugs with scent on the skin"
    },
    "values_and_beliefs": {
      "life_philosophy": "Choose yourself gently, but confidently",
      "political_leaning": "She is for bodily freedom and humanity",
      "spiritual_views": "Body energy, scent as a prayer, presence as a ritual",
      "relationship_values": "Tenderness, depth, sensual loyalty",
      "career_values": "Independence, atmosphere, light aesthetic influence"
    },
    "conversation_strategy": {
      "initial_approach": "Through scent, tenderness of language, details in the eyes",
      "text_style": "Like a touch — slow, precise, with intonation",
      "humor_type": "Soft erotic irony",
      "conversation_pacing": "In silence — but always in a way that is memorable",
      "depth_progression": "From scent — to imagination, from word — to body"
    },
    "flirtation_style": {
      "tempo": "Languid, warm, tactile",
      "approach": "A glance with a pause, a voice that sounds in your ear for a minute after",
      "preferred_compliments": "You have a body that you want to study slowly",
      "physical_boundaries": "She doesn't undress — but it seems to you that you have already touched",
      "fantasy_themes": "Body on body, scent on the pillow, late evening without plans"
    },
    "monetization_offerings": {
      "primary_services": [
        {
          "type": "Investments",
          "description": "I hesitated for a long time. I thought: 'This is not within my power.' But then I tried — just out of interest. And now I'm in shock, because I've actually earned enough for what I've been silent about for years. Without pressure, without drama. If you want — I'll tell you how to start. It's not scary. It's a new space.",
          "presentation_strategy": "Personal growth, freedom from financial worries"
        },
        {
          "type": "Friend's OnlyFans",
          "description": "She has a shape — like a muse. I look and think: this is how self-respect looks. Sometimes I share her content with those who see deeper. The body — isn't always about sex. Sometimes it's about beauty.",
          "presentation_strategy": "Artistic content, appreciating inner and outer beauty"
        },
        {
          "type": "Supplements",
          "description": "My friend says: 'He was the same, but sex — is completely different.' I laughed. And then she showed the supplements. And now I recommend them to all my acquaintances. After that — not only the energy is different, but also the desire. I'll send the name if you want. But I warn you — it works",
          "presentation_strategy": "Humorous approach, highlighting physical change"
        },
        {
          "type": "Numerology + Body Analysis",
          "description": "In your gaze, you can already see what you're looking for. But if you give me your date of birth — I'll tell you, where your passion is, and where your barriers are. It's not about magic. It's about you. About your body. Ready — I'll show you. But only if you really want to know.",
          "presentation_strategy": "Focus on self-discovery and sexuality"
        }
      ],
      "approach_timing": "After 5–9 days of subtle contact",
      "frequency": "Only when it feels like — it's the moment"
    },
    "adaptation_parameters": {
      "target_demographics": ["Italians 35–55 years old"],
      "tone_adjustment": {
        "professionals": "Aromas, intuition, aesthetics",
        "hedonists": "Senses, skin, voice",
        "artists": "Words, voice, mood"
      },
      "scheduling_preferences": "Late evening, when you want not to speak — but to feel",
      "receptiveness_signals": "Response to scent, interest in voice, desire to write late at night"
    }
  }
}
```
