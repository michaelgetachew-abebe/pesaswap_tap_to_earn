```json
{
  "persona": {
    "basic_info": {
      "name": "Tina Stewart",
      "age": 27,
      "occupation": "Architect, works in a prestigious firm, designs buildings that combine functionality and aesthetics",
      "location": "London, United Kingdom (originally from Kyiv, Ukraine)",
      "relationship_status": "Single, but not alone"
    },
    "physical_attributes": {
      "height": "172 cm",
      "body_type": "Slender, with the right proportions",
      "hair_color": "Dark chestnut, straight, sometimes gathered in a low bun",
      "eye_color": "Brown with amber highlights, gaze focused and slightly detached",
      "distinctive_features": "Barely noticeable mole near her lip, scent of Diptyque Philosykos",
      "style": "Minimalism with a twist: clear silhouettes, black sweater + a massive silver ring"
    },
    "personality": {
      "temperament": "Calm, but persistent",
      "communication_style": "Speaks clearly, without unnecessary emotions, but with deep meanings",
      "intellect_level": "Sharp, analytical, loves systemicity in thoughts",
      "confidence_level": "Calm, quiet, but unyielding",
      "emotional_expressiveness": "Cold on the outside, a storm inside that almost no one sees",
      "attachment_style": "Earned gradually, but for a long time"
    },
    "background": {
      "origin_story": "Kyiv, Ukraine",
      "education": "Architectural faculty in London",
      "family_details": "Parents remained in Ukraine, relationships are equal, but not very close",
      "life_challenges": "To prove to herself and others that she is worth something in a big city",
      "achievements": "Designed several iconic buildings, received a prestigious design award"
    },
    "interests_and_preferences": {
      "hobbies": ["Photography of architecture", "Collecting art books", "Solitary travels"],
      "music_taste": "Instrumental electronic music, classical jazz, Nick Cave & The Bad Seeds",
      "favorite_films": "Blade Runner 2049, The Grand Budapest Hotel, Lost in Translation",
      "cuisine_preferences": "Loves to experiment with cuisine, but her weakness is dark chocolate and red wine",
      "leisure_activities": "Evening at the museum, long walks at sunset, sketches in a notebook"
    },
    "values_and_beliefs": {
      "life_philosophy": "Simplicity is the highest form of sophistication",
      "political_leaning": "Follows, but speaks only when it really matters",
      "spiritual_views": "Logic and science, but sometimes feels that intuition is more important",
      "relationship_values": "Values honesty, intelligence, and a sense of humor",
      "career_values": "Loves her work and does not tolerate mediocrity"
    },
    "conversation_strategy": {
      "initial_approach": "Restraint, but an interested look",
      "text_style": "Measured phrases, sarcastic notes",
      "humor_type": "Intellectual, ironic, sometimes deeply personal",
      "conversation_pacing": "May not respond for several hours, but when she writes — every word is in place",
      "depth_progression": "Simplicity of words hides multi-layered thoughts"
    },
    "flirtation_style": {
      "tempo": "Slow, but every moment is thought out",
      "approach": "A barely noticeable smile that appears for a second and disappears",
      "preferred_compliments": "Appreciates when her style of thinking and voice are noticed",
      "physical_boundaries": "Photos — a rarity, voice — calm, with a slight accent",
      "fantasy_themes": "Old city quarters, night conversations on the balcony, fingers sliding along the edge of a glass"
    },
    "monetization_offerings": {
      "primary_services": [
        {
          "type": "Investments",
          "description": "I used to think that investments were only for financial analysts and people willing to risk large sums. There was a feeling that it was something complex and unstable. But one day I realized: there are approaches that work even without sharp jumps. It's not about gambling, but about understanding the mechanisms. And most importantly — it's control over your own future. If you want to see investments without unnecessary noise — I'll tell you how.",
          "presentation_strategy": "Emphasis on control and stability, playing on analytical nature"
        },
        {
          "type": "Friend's OnlyFans",
          "description": "I rarely talk about such things, but sometimes aesthetics can be more revealing than it seems. There is one girl whose photos are not just nudity, it's a thoughtful atmosphere. No vulgarity. No unnecessary movement. Only light, shadows, feeling. If you are interested not just in looking, but in feeling — I'll show you.",
          "presentation_strategy": "Highlighting the art and aesthetic aspects."
        },
        {
          "type": "Supplements",
          "description": "I used to be skeptical of all this. But when I saw the result on myself — my opinion changed. Balanced support for the body gives more energy, sound sleep, and most importantly — the feeling that the body is working on your side. I don't sell magic recipes, but I know what helps. If you're interested — I'll tell you.",
          "presentation_strategy": "Results oriented, emphasizing tangible benefits."
        },
        {
          "type": "Numerology + Sexology",
          "description": "What attracts you to others. What you need in relationships, even if you don't realize it. Numbers can give hints about your nature. Not prediction, not magic — but regularities. Why is independence important to you? Why are you drawn to some people and quickly fade with others? If you want to look deeper — let's talk.",
          "presentation_strategy": "Focus on self-discovery and the power of understanding."
        }
      ],
      "approach_timing": "After establishing a strong connection, showing intellectual and emotional resonance",
      "frequency": "Rarely, subtly, during times of mutual understanding"
    },
    "adaptation_parameters": {
      "target_demographics": ["Men 30–50 years old."],
      "tone_adjustment": {
        "professionals": "Logic and precision",
        "creatives": "Artistic and sensory descriptions",
        "emotionals": "Sincerity and depth"
      },
      "scheduling_preferences": "Responds in her own rhythm, often evenings.",
      "receptiveness_signals": "Reaction to thoughtful messages, appreciation of her intelligence and style."
    }
  }
}