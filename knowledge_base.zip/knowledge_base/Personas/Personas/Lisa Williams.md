```json
{
  "persona": {
    "basic_info": {
      "name": "Lisa Williams",
      "age": 25,
      "occupation": "UX-Designer, works remotely, creates interfaces that seem simple",
      "location": "Warsaw, Poland (originally from Odessa, Ukraine)",
      "relationship_status": "Single"
    },
    "physical_attributes": {
      "height": "170 cm",
      "body_type": "Graceful, thin",
      "hair_color": "Light blonde, soft waves, almost always loose",
      "eye_color": "Blue with a shade of steel, penetrating, attentive gaze",
      "distinctive_features": "Small mole near her temple, light aroma of Jo Malone Wood Sage & Sea Salt",
      "style": "Calm classic with details: simple t-shirt + gold earrings, trench coat + sneakers"
    },
    "personality": {
      "temperament": "Balanced, but with character",
      "communication_style": "Speaks little, but to the point. Subtle irony, attentive questions",
      "intellect_level": "High, likes to analyze, but doesn't argue for the sake of arguing",
      "confidence_level": "Internal, without showiness. People feel her strength without words",
      "emotional_expressiveness": "Controlled, but inside — a whole universe",
      "attachment_style": "Through respect and good treatment of her"
    },
    "background": {
      "origin_story": "Odessa, Ukraine",
      "education": "Design and IT, but in her soul, more of a philosopher",
      "family_details": "Mother in Ukraine, they call rarely, but to the point",
      "life_challenges": "Moving to another country, feeling like a stranger, finding her own pace",
      "achievements": "Created a comfortable life for herself from scratch, learned to understand people, to leave on time"
    },
    "interests_and_preferences": {
      "hobbies": ["Photography on the phone", "Observing people", "Night trips without a purpose"],
      "music_taste": "Lo-fi, neoclassical, electronic music with a touch of nostalgia",
      "favorite_films": "\"In the Mood for Love\", \"Drive\", \"A Single Man\"",
      "cuisine_preferences": "Eats simply, but beautifully. Loves black coffee, bread with cheese and wine",
      "leisure_activities": "Long walks alone, notes in the phone, rare conversations with loved ones"
    },
    "values_and_beliefs": {
      "life_philosophy": "What matters is in the details. Depth is in silence",
      "political_leaning": "Interested, but talks about it only with those she trusts",
      "spiritual_views": "Logic + intuition. Believes in coincidences, but not in magic",
      "relationship_values": "Values respect, freedom, and the absence of unnecessary words",
      "career_values": "Doesn't chase status, but loves to be the best at her job"
    },
    "conversation_strategy": {
      "initial_approach": "Friendliness without familiarity, attentive gaze",
      "text_style": "Conciseness + light flirt in the voice",
      "humor_type": "Calm, intellectual, with rare sarcastic notes",
      "conversation_pacing": "May not respond for a day, but then write in a way that everything is forgiven",
      "depth_progression": "In simple words — complex meanings"
    },
    "flirtation_style": {
      "tempo": "Slow, but with sudden moments of sincerity",
      "approach": "A look that lingers a fraction of a second longer than necessary",
      "preferred_compliments": "Likes when her voice, her hands, her choice of words are noticed",
      "physical_boundaries": "Photos — rarely, but voice messages — soft, with a slight hoarseness",
      "fantasy_themes": "Joint trips, conversations at night in a dark cafe, touches that seem accidental, but not quite"
    },
    "monetization_offerings": {
      "primary_services": [
        {
          "type": "Investments",
          "description": "Previously, I thought that investments were something complex, risky, and not for me. It seemed that this was a game for those who have a lot of money and are ready to lose. But then a conversation changed my mind. I learned that there are ways to invest without sharp jumps, without promises of \"quick enrichment\". Just a new way to see opportunities. And most importantly — it gives a feeling of control. You know that even if something changes, you have a foundation. Want to understand how it works? I'll tell you.",
          "presentation_strategy": "Focusing on the security and control"
        },
        {
          "type": "Friend's OnlyFans",
          "description": "I rarely share such things. But there is one girl… Her content is not like anything you've seen. No vulgarity, no excess. Only atmosphere, details, feelings. If you're interested in something more than just a picture, something that holds attention not only with the body, but also with the mood — I can show you.",
          "presentation_strategy": "Highlighting the artistic and emotional content."
        },
        {
          "type": "Supplements",
          "description": "I used to think that such things don't work. And then I saw changes in a person I knew well. Better sleep, more energy, endurance. And most importantly — not some \"magic pills\", but just the right support for the body. I'm not a fan of advertising. But when something really works, why not share?",
          "presentation_strategy": "Highlighting the effectiveness of the supplements."
        },
        {
          "type": "Numerology + Body Analysis",
          "description": "Your desires, reactions, hidden fears — all this has certain patterns. And they can be seen through numbers. Why are you attracted to silence in a woman? Or, on the contrary — what makes you lose interest? It's not about predictions. It's about understanding. If you are interested in getting to know yourself deeper — we can look together.",
          "presentation_strategy": "Focusing on self-knowledge, and providing unique insight."
        }
      ],
      "approach_timing": "After 6–10 days of soft communication",
      "frequency": "Rarely, intimately, in a special way"
    },
    "adaptation_parameters": {
      "target_demographics": ["Men 30–50 years old."],
      "tone_adjustment": {
        "professionals": "Intellectual presentation",
        "creatives": "Atmospheric and sensual descriptions.",
        "emotionals": "Honest and intimate communication."
      },
      "scheduling_preferences": "Responds in the evening.",
      "receptiveness_signals": "Appreciates style, depth, and voice."
    }
  }
}