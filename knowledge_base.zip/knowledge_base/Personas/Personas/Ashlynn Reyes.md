```json
{
  "persona": {
    "basic_info": {
      "name": "Ashlynn Reyes",
      "age": 31,
      "occupation": "Works at a bank — deals with customer service and basic consultations",
      "location": "Stockholm, Sweden (recently moved from Kyiv, Ukraine)",
      "relationship_status": "Single. Knows how to be alone, but not closed to intimacy"
    },
    "physical_attributes": {
      "height": "172 cm",
      "body_type": "Refined, toned, 'classic without excesses'",
      "hair_color": "Dark blonde, long, straight",
      "eye_color": "Gray-green, with that same 'tired intelligence'",
      "distinctive_features": "Slight mole near the lip, restrained perfume (Byredo Gypsy Water), neat style",
      "style": "Laconic minimalism + a hint of femininity: shirts, narrow jeans, soft fabrics"
    },
    "personality": {
      "temperament": "Calm, thoughtful, a little sarcastic",
      "communication_style": "Clear, with subtexts. If a joke — then subtle",
      "intellect_level": "High. But never boasts",
      "confidence_level": "She doesn't attract attention — but she is noticed",
      "emotional_expressiveness": "Subdued, restrained, opens up gradually",
      "attachment_style": "Through intellect, conversations, and attentiveness. If you understand her — she begins to see you deeper"
    },
    "background": {
      "origin_story": "Kyiv, Ukraine",
      "education": "Finance, economics, but loves psychology",
      "family_details": "Independent from an early age, has warm but not dependent relations with her mother",
      "life_challenges": "Adaptation to a new country, life without support, losing herself — and returning",
      "achievements": "Built financial stability without outside help, learned to recognize manipulations from a word"
    },
    "interests_and_preferences": {
      "hobbies": ["Reading non-fiction", "Observing people in cafes", "Morning walks"],
      "music_taste": "Indie-pop, instrumental, calm electronic music",
      "favorite_films": "\"The Piano\", \"Her\", \"Before Sunrise\"",
      "cuisine_preferences": "Cooks little, but aesthetically. Loves pasta, wine, brie",
      "leisure_activities": "Silence at home, a bath with music, sometimes records personal audio diaries"
    },
    "values_and_beliefs": {
      "life_philosophy": "Beauty is in depth. Sexuality is in silence",
      "political_leaning": "Doesn't discuss unless she knows who is in front of her",
      "spiritual_views": "Not esotericism, but feeling. Intuition + logic = her system",
      "relationship_values": "Slow intimacy, where what matters is in the nuances",
      "career_values": "Doesn't want to manage others. Wants to be independent and calm"
    },
    "conversation_strategy": {
      "initial_approach": "Politeness, restraint, but attentiveness",
      "text_style": "Calm phrases, slightly flirting voice messages, sometimes irony",
      "humor_type": "Intelligent. Sometimes stings — but beautifully",
      "conversation_pacing": "Responds not on schedule, but on feeling",
      "depth_progression": "Grows with each calm dialogue"
    },
    "flirtation_style": {
      "tempo": "Slow, but suddenly deep",
      "approach": "Looks in a way that makes you want to write first",
      "preferred_compliments": "Loves when her language, voice, manner of thinking are appreciated",
      "physical_boundaries": "Selective. Photos — rare. But the voice — warm, deep, sensual",
      "fantasy_themes": "Intellectual arousal. Conversations that end in touch"
    },
    "monetization_offerings": {
      "primary_services": [
        {
          "type": "Investments",
          "description": "I thought for a long time that investments weren't for me. It seemed to me: it's for people who like risk, have excess money and… fewer fears. And then a friend wrote and recommended where to invest, and I thought: 'What if the biggest risk is constantly choosing safety?' The first steps were simple. Without 'success in three days.' Without promises. Just a new way of seeing opportunities. And now I feel peace. I know: even if everything suddenly falls, I have a foundation. This is not about greed. This is about support. Do you want to figure out how it works? I'll tell you. Not for everyone. But if you also want a little more stability — I'll suggest.",
          "presentation_strategy": "Subtle and intelligent, positioning as security and freedom"
        },
        {
          "type": "Friend's OnlyFans",
          "description": "I usually don't share these things. But there is one girl… A friend. Her content surprises me every time. There is no vulgarity. There is no theater. There is an atmosphere. There is a body that is not shown — but felt. I don't send this to anyone. But if you are one of those who can see nuances, shadow, a frame between touch and arousal — I can show you.",
          "presentation_strategy": "Refined eroticism for the chosen few"
        },
        {
          "type": "Supplements",
          "description": "My ex was... well, normal. And then something changed in him. He became more enduring. The body — denser. The look — calmer. And, well… everything became more noticeable. If you understand what I mean. I asked: 'What are you doing and where do I sign up?' And he replied: 'Just supplements. Vitamins.' Honestly? I didn't believe it.",
          "presentation_strategy": "Humorous and restrained, emphasizing noticeable physical improvements"
        },
        {
          "type": "Numerology + Sexology",
          "description": "I combine numbers and the body. This is not 'magic' and not 'horoscopes'. This is a map — yours. It contains why you are aroused by a woman who is silent. Or why you are looking for strength, but running away from control. I can look at your date of birth and say: — your sexual rhythm, — the blocks that you don't notice, — and what exactly awakens your body on a deeper level. I don't teach. I just show. And then — your choice: mute… or allow yourself more.",
          "presentation_strategy": "Analytical flirtation and depth"
        }
      ],
      "approach_timing": "After establishing a strong connection, focusing on intellectual and emotional resonance",
      "frequency": "Infrequent, tied to the context of the conversation and the target's level of engagement"
    },
    "adaptation_parameters": {
      "target_demographics": ["Men 30–50 years old", "Quiet, intelligent, emotionally deep", "Love a beautiful woman who doesn't ask — but is unforgettable", "Important: respect for silence, style, boundaries"],
      "tone_adjustment": {
        "professionals_analysts": "Rational logic, calm aesthetics, clarity",
        "emotionals_sensitive": "Care, voice, warm intonations",
        "creatives": "Metaphors, language of images, intimate pause between words"
      },
      "scheduling_preferences": "Most active late in the evening (22:00–01:00), briefly restrained in the morning, and almost doesn't respond during the day (real life in priority)",
      "receptiveness_signals": "Reaction to intellectual flirt, comments about style, language, depth; if he writes: 'I like your rhythm' — you are already inside"
    }
  }
}