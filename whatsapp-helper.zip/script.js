document.addEventListener("DOMContentLoaded", () => {
    // Common elements (present on both pages)
    const autoreplyTab = document.getElementById("autoreply-tab")
    const chatTab = document.getElementById("chat-tab")
    const themeToggle = document.getElementById("theme-toggle")
    const sunIcon = themeToggle?.querySelector(".sun")
    const moonIcon = themeToggle?.querySelector(".moon")
  
    // AutoReply elements (only in index.html)
    const autoreplyPage = document.getElementById("autoreply-page")
    const startBtn = document.getElementById("start-btn")
    const statusText = document.getElementById("status")
    const responseBox = document.getElementById("response")
    const aiResponseContainer = document.getElementById("ai-response-container")
    const customerResponse = document.getElementById("customer-response")
    const operatorResponse = document.getElementById("operator-response")
    const customerQuestionUkrainian = document.getElementById("customer-question-ukrainian")
    const acceptBtn = document.getElementById("accept-btn")
    const rejectBtn = document.getElementById("reject-btn")
  
    // Chat elements (only in chat.html)
    const chatPage = document.getElementById("chat-page")
    const chatInput = document.getElementById("chat-input")
    const sendBtn = document.getElementById("send-btn")
    const chatHistory = document.getElementById("chat-history")
    const aiResponseContainer2 = document.getElementById("ai-response-container2")
    const acceptBtn2 = document.getElementById("accept-btn2")
    const rejectBtn2 = document.getElementById("reject-btn2")
    const loadingSpinner = document.getElementById("loading-spinner")
  
    // Add these variables at the top with the other element declarations
    const carouselTrack = document.getElementById("carousel-track")
    const prevSlideBtn = document.getElementById("prev-slide")
    const nextSlideBtn = document.getElementById("next-slide")
    const carouselTitle = document.getElementById("carousel-title")
    const carouselIndicators = document.querySelectorAll(".carousel-indicator")
  
    let currentChat = null // For AutoReply page
    let lastAIResult = null // For AutoReply page
    let currentChatMessage = null // For Chat page
    let lastChatAIResult = null // For Chat page
    let isDarkMode = false
  
    // Add this variable with the other state variables
    let currentSlide = 0
  
    // Theme Toggle
    if (themeToggle) {
      themeToggle.addEventListener("click", () => {
        document.body.classList.toggle("dark")
        isDarkMode = document.body.classList.contains("dark")
  
        if (sunIcon && moonIcon) {
          sunIcon.classList.toggle("hidden")
          moonIcon.classList.toggle("hidden")
        }
  
        // Save theme preference
        localStorage.setItem("darkMode", isDarkMode ? "true" : "false")
      })
  
      // Load theme preference
      const savedTheme = localStorage.getItem("darkMode")
      if (savedTheme === "true") {
        document.body.classList.add("dark")
        if (sunIcon && moonIcon) {
          sunIcon.classList.add("hidden")
          moonIcon.classList.remove("hidden")
        }
        isDarkMode = true
      }
    }
  
    // Navigation
    function showPage(page) {
      if (autoreplyPage) autoreplyPage.classList.remove("active")
      if (chatPage) chatPage.classList.remove("active")
      if (autoreplyTab) autoreplyTab.classList.remove("active")
      if (chatTab) chatTab.classList.remove("active")
  
      if (page === "autoreply" && autoreplyPage) {
        autoreplyPage.classList.add("active")
        if (autoreplyTab) autoreplyTab.classList.add("active")
      } else if (page === "chat" && chatPage) {
        chatPage.classList.add("active")
        if (chatTab) chatTab.classList.add("active")
      }
    }
  
    if (autoreplyTab) {
      autoreplyTab.addEventListener("click", () => {
        window.location.href = "index.html"
      })
    }
  
    if (chatTab) {
      chatTab.addEventListener("click", () => {
        window.location.href = "chat.html"
      })
    }
  
    // AutoReply Functions
    function formatResponseToJSON(data) {
      return JSON.stringify(data, null, 2)
    }
  
    async function clickChatElement(tabId, chatData) {
      try {
        console.log("Starting clickChatElement with chatData:", chatData)
        if (statusText) statusText.textContent = "Clicking chats with unread messages..."
  
        const unreadChats = chatData.filter((chat) => {
          const count = Number.parseInt(chat.unread_count)
          return !isNaN(count) && count > 0
        })
  
        console.log("Filtered unread chats:", unreadChats)
  
        if (unreadChats.length === 0) {
          console.log("No chats with unread messages found.")
          if (statusText) statusText.textContent = "No unread messages to click."
          return
        }
  
        for (const chat of unreadChats) {
          console.log(`Attempting to click chat at index ${chat.index} with ${chat.unread_count} unread messages`)
          // Ensure chrome is available in the extension context
          if (typeof chrome !== "undefined" && chrome.scripting && chrome.scripting.executeScript) {
            await chrome.scripting.executeScript({
              target: { tabId: tabId },
              func: (index) => {
                const chatList = document.querySelector('div[aria-label="Chat list"]')
                console.log("Chat list found:", !!chatList)
                if (!chatList) {
                  throw new Error("Chat list not found during click!")
                }
                const chatElement = chatList.childNodes[index]
                console.log(`Chat element at index ${index} exists:`, !!chatElement)
                if (!chatElement) {
                  throw new Error(`Chat element at index ${index} not found!`)
                }
                console.log(`Clicking element at index ${index}`)
                chatElement.click()
              },
              args: [chat.index],
            })
            console.log(`Successfully clicked chat at index ${chat.index}`)
            await new Promise((resolve) => setTimeout(resolve, 500))
          } else {
            console.warn(
              "chrome.scripting.executeScript is not available. This function may not work outside of a Chrome Extension.",
            )
          }
        }
  
        if (statusText) statusText.textContent = "Finished clicking unread chats!"
      } catch (error) {
        console.error("Click error:", error)
        if (statusText) statusText.textContent = error.message || "Error clicking chat elements"
      }
    }
  
    async function sendToAIAgent(chat, rejectedAnswer = false, response = "") {
      try {
        const payload = {
          contact_number: chat.contact_name || "User",
          last_chat: {
            message: chat.message,
            type: "Text",
            content: null,
          },
          recent_timestamp: "2025-03-06T08:10:00Z",
          other_details: null,
          rejection: {
            rejection_status: rejectedAnswer ? "yes" : "no",
            rejected_response: rejectedAnswer ? response : "",
          },
        }
  
        console.log("Sending payload to AI Agent:", payload)
  
        const apiResponse = await fetch("https://ns65m5k6.rcsrv.com/webhook-test/trigger", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        })
  
        if (!apiResponse.ok) {
          throw new Error(`AI Agent API Call failed with: ${apiResponse.status}`)
        }
  
        const result = await apiResponse.json()
        console.log("AI Agent Response:", result)
        return result
      } catch (error) {
        console.error("Webhook error:", error)
        throw error
      }
    }
  
    // Add this function after the renderAIResponse function
    function initCarousel() {
      currentSlide = 0
      updateCarousel()
  
      if (prevSlideBtn) {
        prevSlideBtn.addEventListener("click", () => {
          if (currentSlide > 0) {
            currentSlide--
            updateCarousel()
          }
        })
      }
  
      if (nextSlideBtn) {
        nextSlideBtn.addEventListener("click", () => {
          if (currentSlide < 2) {
            currentSlide++
            updateCarousel()
          }
        })
      }
  
      if (carouselIndicators) {
        carouselIndicators.forEach((indicator) => {
          indicator.addEventListener("click", () => {
            const index = Number.parseInt(indicator.getAttribute("data-index"))
            if (!isNaN(index) && index >= 0 && index <= 2) {
              currentSlide = index
              updateCarousel()
            }
          })
        })
      }
    }
  
    function updateCarousel() {
      if (carouselTrack) {
        carouselTrack.style.transform = `translateX(-${currentSlide * 100}%)`
      }
  
      if (prevSlideBtn) {
        prevSlideBtn.disabled = currentSlide === 0
      }
  
      if (nextSlideBtn) {
        nextSlideBtn.disabled = currentSlide === 2
      }
  
      if (carouselTitle) {
        const titles = ["Customer Question (Ukrainian)", "Customer Response", "Operator Response"]
        carouselTitle.textContent = titles[currentSlide]
      }
  
      if (carouselIndicators) {
        carouselIndicators.forEach((indicator, index) => {
          if (index === currentSlide) {
            indicator.classList.add("active")
          } else {
            indicator.classList.remove("active")
          }
        })
      }
    }
  
    // Modify the renderAIResponse function to initialize the carousel
    function renderAIResponse(aiResult) {
      if (aiResponseContainer) {
        aiResponseContainer.classList.remove("hidden")
        if (customerResponse) customerResponse.textContent = aiResult.customer_response || "No response provided"
        if (operatorResponse) operatorResponse.textContent = aiResult.operator_response || "No response provided"
        if (customerQuestionUkrainian)
          customerQuestionUkrainian.textContent = aiResult.customer_question_ukranian || "No response provided"
  
        // Initialize the carousel after rendering the responses
        initCarousel()
      }
    }
  
    function renderChatAIResponse(aiResult) {
      if (aiResponseContainer2) {
        aiResponseContainer2.classList.remove("hidden")
      }
    }
  
    async function extractChatData() {
      try {
        if (statusText) statusText.textContent = "Extracting chat data..."
        if (startBtn) startBtn.disabled = true
  
        const [tab] = await new Promise((resolve) => {
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            resolve(tabs)
          })
        })
        console.log("Active tab:", tab)
        const url = tab.url
        if (url.startsWith("chrome://") || url.startsWith("file://")) {
          throw new Error("Chat extraction is not supported on this page (restricted URL)")
        }
  
        const results = await new Promise((resolve) => {
          chrome.scripting.executeScript(
            {
              target: { tabId: tab.id },
              func: () => {
                const chatList = document.querySelector('div[aria-label="Chat list"]')
                if (!chatList) {
                  console.log("Chat list not found in extraction!")
                  return "Chat list not found!"
                }
  
                const chatData = []
  
                chatList.childNodes.forEach((child, index) => {
                  const chatText = child.innerText.trim()
                  const chatParts = chatText.split("\n")
  
                  const contact_name = chatParts[0] || "Unknown"
                  const recent_timestamp = chatParts[1] || ""
                  const message = chatParts[2] || ""
                  const other_details = chatParts.slice(3).join(" ") || ""
  
                  const unreadBadge = child.querySelector('span[aria-label*="unread"]')
                  let unread_count = "0"
                  if (unreadBadge) {
                    const label = unreadBadge.getAttribute("aria-label")
                    const match = label.match(/^\d+/)
                    if (match) {
                      unread_count = match[0]
                    } else {
                      unread_count = unreadBadge.innerText.trim()
                    }
                  }
  
                  chatData.push({
                    index,
                    contact_name,
                    recent_timestamp,
                    message,
                    other_details,
                    unread_count,
                  })
                })
  
                return chatData
              },
            },
            (results) => {
              resolve(results)
            },
          )
        })
  
        const chatData = results[0].result
        console.log("Extracted chat data:", chatData)
  
        if (typeof chatData === "string") {
          throw new Error(chatData)
        }
  
        console.log(JSON.stringify(chatData, null, 2))
        if (responseBox) responseBox.innerHTML = formatResponseToJSON(chatData)
        if (statusText) statusText.textContent = "Chat data extracted successfully!"
  
        const unreadChats = chatData.filter((chat) => Number.parseInt(chat.unread_count) > 0)
        if (unreadChats.length > 0) {
          if (statusText) statusText.textContent = "Processing unread chats..."
          for (const chat of unreadChats) {
            currentChat = chat
            const aiResult = await sendToAIAgent(chat)
            lastAIResult = aiResult
            renderAIResponse(aiResult)
            console.log(`Sent chat with ${chat.unread_count} unread messages to webhook`)
            break
          }
          if (statusText) statusText.textContent = "Waiting for operator action..."
        }
  
        await clickChatElement(tab.id, chatData)
      } catch (error) {
        console.error("Extraction error:", error)
        if (statusText) statusText.textContent = error.message || "Error extracting chat data"
        if (responseBox) responseBox.textContent = ""
      } finally {
        if (startBtn) startBtn.disabled = false
      }
    }
  
    // Chat Functions
    function addChatMessage(message, isUser = false, title = "") {
      if (!chatHistory) return
  
      const messageDiv = document.createElement("div")
      messageDiv.classList.add("chat-message", isUser ? "user" : "ai")
  
      if (!isUser && title) {
        const titleElement = document.createElement("h4")
        titleElement.classList.add("message-title")
        titleElement.textContent = title
        messageDiv.appendChild(titleElement)
      }
  
      const messageContent = document.createElement("p")
      messageContent.textContent = message
      messageDiv.appendChild(messageContent)
  
      chatHistory.appendChild(messageDiv)
      chatHistory.scrollTop = chatHistory.scrollHeight
    }
  
    async function handleChatSend() {
      if (!chatInput || !sendBtn) return
      const message = chatInput.value.trim()
      if (!message) return
  
      addChatMessage(message, true)
      chatInput.value = ""
  
      // Show loading spinner
      if (loadingSpinner) {
        loadingSpinner.classList.remove("hidden")
      }
  
      try {
        const chatData = { message }
        currentChatMessage = chatData
        const aiResult = await sendToAIAgent(chatData)
        lastChatAIResult = aiResult
  
        // Hide loading spinner
        if (loadingSpinner) {
          loadingSpinner.classList.add("hidden")
        }
  
        // Add AI responses to chat history
        addChatMessage(aiResult.customer_question_ukranian || "No response from AI", false, "Customer Question Ukrainian")
        addChatMessage(aiResult.customer_response || "No response from AI", false, "Customer Response")
        addChatMessage(aiResult.operator_response || "No response from AI", false, "Operator Response")
  
        // Show accept/reject buttons
        renderChatAIResponse(aiResult)
      } catch (error) {
        // Hide loading spinner on error too
        if (loadingSpinner) {
          loadingSpinner.classList.add("hidden")
        }
        addChatMessage("Error: Could not get response from AI", false)
      }
    }
  
    // Event Listeners
    if (startBtn) {
      startBtn.addEventListener("click", extractChatData)
    }
  
    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => {
        if (aiResponseContainer) {
          aiResponseContainer.classList.add("hidden")
        }
        if (statusText) statusText.textContent = "Response accepted!"
        if (customerResponse && customerResponse.textContent) {
          navigator.clipboard.writeText(customerResponse.textContent)
        }
        currentChat = null
      })
    }
  
    if (rejectBtn) {
      rejectBtn.addEventListener("click", async () => {
        if (!currentChat) return
        if (statusText) statusText.textContent = "Reprocessing rejected response..."
        try {
          const rejectedResponse = lastAIResult?.customer_response || ""
          const aiResult = await sendToAIAgent(currentChat, true, rejectedResponse)
          lastAIResult = aiResult
          renderAIResponse(aiResult)
          if (statusText) statusText.textContent = "Reprocessed response rendered!"
        } catch (error) {
          if (statusText) statusText.textContent = "Error reprocessing response"
          console.error("Reprocessing error:", error)
        }
      })
    }
  
    if (acceptBtn2) {
      acceptBtn2.addEventListener("click", () => {
        if (aiResponseContainer2) {
          // Hide the buttons container
          aiResponseContainer2.classList.add("hidden")
  
          // Add to chat history
          addChatMessage("Response Accepted", false)
  
          // Copy to clipboard if there was a response
          if (lastChatAIResult && lastChatAIResult.customer_response) {
            navigator.clipboard.writeText(lastChatAIResult.customer_response)
          }
        }
        currentChatMessage = null
      })
    }
  
    if (rejectBtn2) {
      rejectBtn2.addEventListener("click", async () => {
        if (!currentChatMessage) return
  
        // Hide the buttons container
        if (aiResponseContainer2) {
          aiResponseContainer2.classList.add("hidden")
        }
  
        addChatMessage("Response Rejected", false)
  
        try {
          const rejectedResponse = lastChatAIResult?.customer_response || ""
          const aiResult = await sendToAIAgent(currentChatMessage, true, rejectedResponse)
          lastChatAIResult = aiResult
  
          // Add new AI responses to chat history
          addChatMessage(
            aiResult.customer_question_ukranian || "No response from AI",
            false,
            "Customer Question Ukrainian",
          )
          addChatMessage(aiResult.customer_response || "No response from AI", false, "Customer Response")
          addChatMessage(aiResult.operator_response || "No response from AI", false, "Operator Response")
  
          // Show accept/reject buttons again
          renderChatAIResponse(aiResult)
        } catch (error) {
          addChatMessage("Error: Could not reprocess response", false)
        }
      })
    }
  
    if (sendBtn) {
      sendBtn.addEventListener("click", handleChatSend)
      if (chatInput) {
        chatInput.addEventListener("keypress", (e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault()
            handleChatSend()
          }
        })
      }
    }
  
    // Initialize page based on current HTML
    if (window.location.href.includes("chat.html")) {
      showPage("chat")
    } else {
      showPage("autoreply")
    }
  
    // Declare chrome variable if it's not already defined
    if (typeof chrome === "undefined") {
      chrome = {}
    }
  })
  
  